/* Trace deck engine.
   - Keyboard-only navigation with presenter steps; nine slide transitions; five title effects.
   - ?pdf → static mode: all slides stacked and fully built, for PDF export. */
(() => {
  const Q = new URLSearchParams(location.search);
  const STATIC = Q.has('pdf');
  const LANG = 'en';
  const L = en => en;
  const deck = document.querySelector('.deck');
  const slides = [...deck.querySelectorAll('.slide')];
  const N = slides.length;
  const NS = 'http://www.w3.org/2000/svg';
  const LOGO = '<svg viewBox="0 0 28 28"><path d="M3 20 9.5 11l6 5L25 5" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="3" cy="20" r="2.6" fill="currentColor"/><circle cx="9.5" cy="11" r="2.6" fill="currentColor"/><circle cx="15.5" cy="16" r="2.6" fill="currentColor"/><circle cx="25" cy="5" r="3.4" fill="currentColor"/></svg>';
  const PARTS = {
    intro: ['IND210 · CW2', 'IND210 · CW2'], p0: ['00 · in one line', '00 · 一句话'], p1: ['01 · tangled', '01 · 缠绕'],
    p2: ['02 · listen', '02 · 倾听'], p3: ['03 · untangle', '03 · 理清'], p4: ['04 · trace', '04 · Trace'],
    p5: ['05 · build', '05 · 落地'], end: ['06 · close', '06 · 结语'],
  };

  /* ---------- animation loops: per-slide frame callbacks (2D canvas and WebGL scenes) ---------- */
  const LOOPS = new Map();
  let enteredAt = performance.now();
  window.DECK = {
    LANG, STATIC, L,
    // fn(t, age): t = seconds, age = seconds since the slide was entered. In static mode it runs once, fully built.
    loop(sl, fn) { if (STATIC) return document.fonts.ready.then(() => fn(0, 99)); if (!LOOPS.has(sl)) LOOPS.set(sl, []); LOOPS.get(sl).push(fn); },
  };

  /* ---------- helpers ---------- */
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const svgEl = (tag, attrs = {}) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };
  const rng = seed => () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  const box = e => { let x = 0, y = 0; const w = e.offsetWidth, h = e.offsetHeight;
    for (let n = e; n && !n.classList.contains('slide'); n = n.offsetParent) { x += n.offsetLeft; y += n.offsetTop; }
    return { x, y, w, h, cx: x + w / 2, cy: y + h / 2, r: x + w, b: y + h }; };
  const sunflower = (n, cx, cy, sp) => Array.from({ length: n }, (_, k) => {
    const r = sp * .56 * Math.sqrt(k + .5), t = k * 2.39996;
    return [cx + r * Math.cos(t), cy + r * Math.sin(t)];
  });
  function addDot(fig, x, y, i, cls = '', rand = Math.random) {
    const d = el('i', 'dot ' + cls);
    const a = rand() * Math.PI * 2, r = 500 + rand() * 500;
    d.style.cssText = `--x:${x}px;--y:${y}px;--sx:${960 + Math.cos(a) * r}px;--sy:${540 + Math.sin(a) * r}px;--i:${i}`;
    fig.append(d);
    return d;
  }
  const label = (fig, x, y, html, cls = '') => { const l = el('div', 'fl ' + cls, html); l.style.left = x + 'px'; l.style.top = y + 'px'; fig.append(l); return l; };
  const drawable = (p, d) => { p.setAttribute('data-a', 'draw'); p.style.setProperty('--d', d); };
  const measure = root => root.querySelectorAll('[data-a="draw"]').forEach(p => { if (p.getTotalLength) p.style.setProperty('--len', Math.ceil(p.getTotalLength())); });

  /* ---------- chrome (header, footer, construction lines, dust) ---------- */
  slides.forEach((sl, i) => {
    const prev = i ? String(i).padStart(2, '0') : '00', curN = String(i + 1).padStart(2, '0');
    const hd = el('div', 'hd');
    hd.innerHTML = `<span class="brand">${LOGO}TRACE <span>✦ ${L(...(PARTS[sl.dataset.part] || ['', '']))}</span></span>
      <span class="ticks">${slides.map((_, k) => `<i class="${k < i ? 'done' : k === i ? 'cur' : ''}"></i>`).join('')}</span>
      <span class="pg"><b class="roll"><span><i>${prev}</i><i>${curN}</i></span></b><span> / ${N}</span></span>`;
    sl.append(hd);
    if (sl.dataset.src) sl.append(el('div', 'ft', STATIC ? sl.dataset.src.replace(/\s*·\s*(按\s*)?→[^·]*/g, '') : sl.dataset.src));
    const spec = sl.dataset.lines ?? 'v:96,1824';
    if (spec !== 'none') {
      const Lw = el('div', 'L'), vs = [], hs = [];
      spec.split(/\s+/).forEach(t => { const [k, list] = t.split(':'); (k === 'v' ? vs : hs).push(...list.split(',').map(Number)); });
      vs.forEach((x, k) => { const v = el('i', 'v' + (k % 2 ? ' rev' : '')); v.style.cssText = `left:${x}px;animation-delay:${k * .09}s`; Lw.append(v); });
      hs.forEach((y, k) => { const h = el('i', 'h' + (k % 2 ? '' : ' rev')); h.style.cssText = `top:${y}px;animation-delay:${k * .09 + .1}s`; Lw.append(h); });
      vs.forEach(x => hs.forEach(y => { const c = el('i', 'x'); c.style.cssText = `left:${x}px;top:${y}px`; Lw.append(c); }));
      sl.prepend(Lw);
    }
    if (sl.classList.contains('black')) {
      const dust = el('div', 'dust'), r = rng(i * 31 + 7);
      for (let k = 0; k < 42; k++) {
        const d = el('i');
        d.style.cssText = `left:${(r() * 100).toFixed(1)}%;top:${(r() * 100).toFixed(1)}%;--s:${(.6 + r() * 1.8).toFixed(2)};animation-duration:${(9 + r() * 14).toFixed(1)}s;animation-delay:${(-r() * 20).toFixed(1)}s`;
        dust.append(d);
      }
      sl.prepend(dust);
    }
  });
  deck.append(el('div', 'cam'));

  /* ---------- figures ---------- */
  const FIG = {};
  FIG.untangle = svg => {
    const W = +svg.dataset.w, H = +svg.dataset.h, r = rng(+svg.dataset.seed || 1), vx = +svg.dataset.vx || W * 1.05, vy = +svg.dataset.vy || H * .55;
    const n = 38, hot = 23;
    svg.setAttribute('width', W); svg.setAttribute('height', H);
    const g = svgEl('g', { class: 'ul' });
    for (let k = 0; k < n; k++) {
      const y0 = H * .06 + k * H * .88 / (n - 1), bend = (r() - .5) * 26;
      const d = `M-20 ${y0.toFixed(1)}C${(W * .3).toFixed(1)} ${(y0 + bend).toFixed(1)} ${(vx - (vx + 20) * .35).toFixed(1)} ${(vy + (y0 - vy) * .22).toFixed(1)} ${vx} ${vy}`;
      const cls = k === hot ? 'b' : k % 6 === 0 ? 'w' : '';
      const p = svgEl('path', { d, class: 'line ' + cls });
      drawable(p, `${(.1 + k * .02).toFixed(2)}s`);
      g.append(p);
      if (k % 3 === 0 || k === hot) {
        const q = svgEl('path', { d, class: 'pulse ' + cls });
        q.style.cssText = `animation-duration:${(3.2 + r() * 3).toFixed(1)}s;animation-delay:${(-r() * 6).toFixed(1)}s`;
        g.append(q);
      }
    }
    svg.append(g);
    measure(svg);
    svg.querySelectorAll('.pulse').forEach(q => q.style.setProperty('--len', Math.ceil(q.getTotalLength())));
  };

  // 08 · why students hold back: each dot is a respondent, grouped by the first reason they gave.
  FIG.links = svg => {
    const sl = svg.closest('.slide');
    svg.setAttribute('width', 1920); svg.setAttribute('height', 1080);
    svg.dataset.links.trim().split(/\s+/).forEach((spec, k) => {
      const [a, b] = spec.split('>').map(id => sl.querySelector('#' + id)), A = box(a), B = box(b);
      const ax = A.r + 6, ay = A.cy, bx = B.x - 6, by = B.cy, m = (bx - ax) / 2;
      const ga = (a.dataset.g || '').split(' '), gb = (b.dataset.g || '').split(' ');
      const p = svgEl('path', { d: `M${ax} ${ay}C${ax + m} ${ay} ${bx - m} ${by} ${bx} ${by}`, class: 'lk ' + ga.filter(g => g && gb.includes(g)).map(g => 'g' + g).join(' ') });
      drawable(p, `${(.4 + k * .04).toFixed(2)}s`);
      svg.append(p);
    });
    measure(svg);
  };

  // 07 · tally strip: one cell per respondent, the counted ones lit.
  // 19 · timeline (month units from 1 Dec 2026)
  FIG.gantt = g => {
    const ROWS = [
      [L('Usability test', '可用性测试'), L('5 students, 2 tutors, a mock crit', '5 名学生、2 位老师、一次模拟评图'), .25, 1.6, '', [1.6, L('findings', '结论')]],
      [L('Iterate to v3', '迭代到 v3'), L('card, form and stand', '卡片、表单与支架'), 1.5, 2.4, '', [2.4, L('v3 ready', 'v3 完成')]],
      [L('Pilot set-up', '试点准备'), L('HTTPS server, privacy review, rule templates', 'HTTPS 服务器、隐私评估、规则模板'), 2.2, 3.2, ''],
      [L('Studio pilot', '工作室试点'), L('one Year-2 module, one project, one crit', '一门大二课程、一个项目、一次评图'), 3.2, 5.6, 'pilot', [4.6, L('pilot crit', '试点评图')]],
      [L('Evaluate', '评估'), L('declaring rate, tutor workload, card quality', '申报率、老师工作量、卡片质量'), 5.5, 6.8, '', [6.8, L('go / no-go', '是否推广')]],
      [L('Prepare to scale', '推广准备'), L('department rollout, iOS and QR fallback', '全系推广、iOS 版与二维码备选'), 7, 10, ''],
    ];
    const pct = m => `${m * 10}%`;
    ROWS.forEach(([t, d, a, b, kind, ms], k) => {
      g.insertAdjacentHTML('beforeend', `<div class="t" data-a="left" style="--d:${.3 + k * .1}s">${t}<span>${d}</span></div>
        <div class="track"><i class="bar ${kind}" data-a="gx" style="left:${pct(a)};width:${pct(b - a)};--d:${.6 + k * .12}s"></i>
        ${ms ? `<i class="ms" data-a="pop" style="left:${pct(ms[0])};--d:${1.2 + k * .12}s"></i><span class="msl" data-a="fade" style="left:${pct(ms[0])};--d:${1.3 + k * .12}s">${ms[1]}</span>` : ''}</div>`);
    });
  };

  document.querySelectorAll('[data-fig]').forEach(f => FIG[f.dataset.fig](f));
  measure(document);

  /* ---------- title effects (applied after translation) ---------- */
  const textNodes = root => { const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), out = []; while (w.nextNode()) out.push(w.currentNode); return out; };
  document.querySelectorAll('[data-te]').forEach(h => {
    const fx = h.dataset.te;
    h.classList.add('te-' + fx);
    if (fx === 'rise') {
      h.innerHTML = h.innerHTML.split(/<br\s*\/?>/i).map((ln, k) => `<span class="mk"><span data-a="rise" style="--d:${(.05 + k * .09).toFixed(2)}s">${ln}</span></span>`).join('');
    } else if (fx === 'chars') {
      let i = 0;
      textNodes(h).forEach(t => {
        const frag = document.createDocumentFragment();
        t.textContent.split(/(\s+)/).forEach(part => {
          if (!part) return;
          if (/^\s+$/.test(part)) return frag.append(document.createTextNode(part));
          const w = el('span', 'w');
          [...part].forEach(c => { const s = el('span', 'ch', c === '<' ? '&lt;' : c); s.style.setProperty('--d', (i++ * .022).toFixed(3) + 's'); w.append(s); });
          frag.append(w);
        });
        t.replaceWith(frag);
      });
    } else if (fx === 'wipe') {
      h.innerHTML = `<span class="wpi">${h.innerHTML}</span>`;
    } else if (fx === 'blur') {
      h.setAttribute('data-a', 'blurt');
    } else if (fx === 'scr') {
      h.setAttribute('data-a', 'fade');
      h.dataset.scrNodes = '';
    }
  });

  const GLYPHS = '▓▒░<>/\\_-+*#01ABCDEFGHJKLMNPRSTUVWXYZ';
  const scrubs = new Map();
  function scramble(root) {
    scrubs.get(root)?.();
    if (STATIC) return;
    const clone = root.cloneNode(true), originals = [root, ...root.querySelectorAll('*')];
    const colors = originals.map(e => [e.style.getPropertyValue('color'), e.style.getPropertyPriority('color')]);
    const position = root.style.position;
    if (getComputedStyle(root).position === 'static') root.style.position = 'relative';
    clone.classList.add('scr');
    [clone, ...clone.querySelectorAll('*')].forEach(e => {
      ['data-a', 'data-te', 'data-scr-nodes', 'data-count', 'data-t', 'data-step', 'id'].forEach(a => e.removeAttribute(a));
    });
    clone.setAttribute('aria-hidden', 'true');
    clone.style.cssText += ';position:absolute;inset:0;width:100%;height:100%;margin:0;pointer-events:none;animation:none;transform:none;opacity:1';
    const copies = [clone, ...clone.querySelectorAll('*')];
    originals.forEach((e, i) => copies[i].style.color = getComputedStyle(e).color);
    originals.forEach(e => e.style.setProperty('color', 'transparent', 'important'));
    root.append(clone);
    let frame;
    const clean = () => {
      cancelAnimationFrame(frame); clone.remove();
      originals.forEach((e, i) => colors[i][0] ? e.style.setProperty('color', ...colors[i]) : e.style.removeProperty('color'));
      root.style.position = position; scrubs.delete(root);
    };
    scrubs.set(root, clean);
    const nodes = textNodes(clone).map(t => [t, t._final ??= t.textContent]);
    const total = nodes.reduce((a, [, f]) => a + f.length, 0), t0 = performance.now(), dur = 650 + total * 6;
    const tick = now => {
      const p = Math.min(1, (now - t0) / dur);
      let budget = Math.floor(total * p);
      nodes.forEach(([t, f]) => {
        const n = Math.max(0, Math.min(f.length, budget)); budget -= f.length;
        t.textContent = f.slice(0, n) + [...f.slice(n)].map(c => /\s/.test(c) ? c : GLYPHS[Math.random() * GLYPHS.length | 0]).join('');
      });
      if (p < 1) frame = requestAnimationFrame(tick); else clean();
    };
    frame = requestAnimationFrame(tick);
  }
  function count(e) {
    const final = e.dataset.final ??= e.textContent, to = parseFloat(final), t0 = performance.now(), dur = 1300, delay = parseFloat(e.dataset.delay || .3) * 1000;
    if (isNaN(to)) return;
    e.textContent = final;
    e.style.display = 'inline-block';
    e.style.whiteSpace = 'nowrap';
    e.style.width = e.offsetWidth + 'px';
    e.style.overflow = 'visible';
    e.style.textAlign = 'right';
    e.textContent = '0';
    const tick = now => {
      const p = Math.max(0, Math.min(1, (now - t0 - delay) / dur));
      e.textContent = Math.round(to * (1 - Math.pow(2, -10 * p)));
      if (p < 1) requestAnimationFrame(tick); else { e.textContent = final; ['display', 'width', 'text-align', 'white-space', 'font-variant', 'overflow'].forEach(p => e.style.removeProperty(p)); }
    };
    requestAnimationFrame(tick);
  }

  /* ---------- static (PDF) mode ---------- */
  if (STATIC) {
    document.body.classList.add('static');
    document.querySelectorAll('svg').forEach(s => { s.pauseAnimations?.(); s.setCurrentTime?.(0); });
    slides.forEach(sl => { sl.classList.add('on'); sl.dataset.cur = sl.dataset.staticStep ?? (sl.dataset.steps || 0); sl.querySelectorAll('[data-step]').forEach(e => e.classList.add('shown')); });
    return;
  }

  /* ---------- navigation & transitions ---------- */
  const steps = sl => +(sl.dataset.steps || 0);
  let cur = 0, step = 0, timer = 0, generation = 0;
  const render = () => { const sl = slides[cur]; sl.dataset.cur = step; sl.querySelectorAll('[data-step]').forEach(e => e.classList.toggle('shown', +e.dataset.step <= step)); };
  const DUR = { pixel: 640, blinds: 820, iris: 950, diag: 950, wipe: 900, push: 900, scan: 950, zoom: 900, glitch: 560 };
  const BG = { grey: '#dcdcd8', black: '#0b0b0b', blue: '#3a3af0' };
  const mode = sl => sl.classList.contains('black') ? 'black' : sl.classList.contains('blue') ? 'blue' : 'grey';
  const px = el('div', 'px'); for (let k = 0; k < 144; k++) px.append(el('i')); deck.append(px);
  const bl = el('div', 'bl'); for (let k = 0; k < 12; k++) bl.append(el('i')); deck.append(bl);
  const bar = el('div', 'tbar'); deck.append(bar);
  const overlay = (o, color) => { o.querySelectorAll('i').forEach((c, k) => { c.style.background = color(k); c.style.setProperty('--d', (o === px ? (k * 37 % 144) / 144 * .18 : (deck.classList.contains('back') ? 11 - k : k) * .02).toFixed(3) + 's'); }); o.classList.remove('cover', 'reveal'); void o.offsetWidth; o.classList.add('cover'); };

  function enter(sl) {
    enteredAt = performance.now();
    slides.forEach(s => s !== sl && !s.classList.contains('leaving') && s.classList.remove('on'));
    sl.classList.remove('on'); void sl.offsetWidth; sl.classList.add('on');
    sl.querySelectorAll('[data-count]').forEach(count);
  }
  function settle() {
    generation++;
    clearTimeout(timer);
    slides.forEach(s => s.classList.remove('leaving', ...[...s.classList].filter(c => c.startsWith('tri-') || c.startsWith('tro-'))));
    slides.forEach(s => s !== slides[cur] && s.classList.remove('on'));
    px.classList.remove('cover', 'reveal'); bl.classList.remove('cover', 'reveal');
    bar.className = 'tbar';
  }
  function show(i, s = 0, animate = true) {
    i = Math.max(0, Math.min(N - 1, i));
    const from = slides[cur], to = slides[i];
    if (to === from && to.classList.contains('on')) { settle(); step = s; render(); return; }
    settle();
    scrubs.forEach(clean => clean());
    deck.classList.toggle('back', i < cur);
    const tr = animate ? (to.dataset.tr || 'zoom') : null;
    const go = () => { cur = i; step = s; enter(to); render(); history.replaceState(null, '', location.search + '#' + (i + 1)); };
    if (!tr) return go();
    if (tr === 'pixel' || tr === 'blinds') {
      const o = tr === 'pixel' ? px : bl;
      overlay(o, () => BG[mode(to)]);
      const token = generation;
      // Completed cover animations hold their last frame until reveal starts.
      const finished = () => new Promise(resolve => {
        const animations = o.getAnimations({ subtree: true });
        const fallback = setTimeout(() => {
          if (token === generation) animations.forEach(a => { try { a.finish(); } catch {} });
          resolve();
        }, 1200);
        Promise.all(animations.map(a => a.finished)).catch(() => {}).then(() => {
          clearTimeout(fallback); resolve();
        });
      });
      (async () => {
        await finished();
        if (token !== generation) return;
        go();
        // Keep the swap covered for a painted frame, even under CPU load.
        await Promise.all([
          new Promise(r => setTimeout(r, tr === 'pixel' ? 70 : 0)),
          new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))
        ]);
        if (token !== generation) return;
        o.classList.replace('cover', 'reveal');
        await finished();
        if (token === generation) settle();
      })();
      return;
    }
    from.classList.add('leaving', 'tro-' + tr);
    go();
    to.classList.add('tri-' + tr);
    if (tr === 'wipe' || tr === 'scan') { bar.className = 'tbar ' + tr; void bar.offsetWidth; bar.classList.add('run'); }
    timer = setTimeout(settle, DUR[tr]);
  }
  const next = () => step < steps(slides[cur]) ? (step++, render()) : cur < N - 1 && show(cur + 1, 0);
  const prev = () => step > 0 ? (step--, render()) : cur > 0 && show(cur - 1, steps(slides[cur - 1]));

  /* ---------- scale, keys, idle cursor ---------- */
  const fit = () => document.documentElement.style.setProperty('--s', Math.min(innerWidth / 1920, innerHeight / 1080));
  fit();
  addEventListener('resize', fit);
  addEventListener('keydown', e => {
    if (['ArrowRight', 'ArrowDown', 'PageDown', ' ', 'Enter'].includes(e.key)) { e.preventDefault(); next(); }
    else if (['ArrowLeft', 'ArrowUp', 'PageUp', 'Backspace'].includes(e.key)) { e.preventDefault(); prev(); }
    else if (e.key === 'Home') show(0);
    else if (e.key === 'End') show(N - 1, steps(slides[N - 1]));
    else if (e.key === 'c' || e.key === 'C') deck.classList.toggle('showcam');
    else if (e.key === 'f' || e.key === 'F') document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen?.();
  });
  let idle;
  addEventListener('mousemove', () => { document.body.classList.remove('idle'); clearTimeout(idle); idle = setTimeout(() => document.body.classList.add('idle'), 1500); });
  addEventListener('hashchange', () => show((parseInt(location.hash.slice(1)) || 1) - 1, 0, false));
  show((parseInt(location.hash.slice(1)) || 1) - 1, 0, false);
  (function tick(now) {
    const fs = LOOPS.get(slides[cur]);
    if (fs) { const age = (now - enteredAt) / 1000; fs.forEach(f => f(now / 1000, age)); }
    requestAnimationFrame(tick);
  })(performance.now());
})();
