/* Trace deck · 3D product scenes (Three.js r149 UMD, global THREE).
   One WebGL renderer draws whichever scene is on screen and copies the frame into that scene's own 2D canvas,
   so geometry, textures and the studio environment are shared by slides 14, 15, 16, 17 and 20.
   Models follow the printed prototype: a one-piece hollow A-frame, a front ledge with three slots, sleeved
   49 × 85 mm cards (faces exported by the prototype itself) and a round NFC tag. Units are millimetres.
   Textures come from window.TEX (data URLs from _tools/build_textures.mjs; file:// images would taint WebGL). */
(() => {
  const D = window.DECK, T = window.THREE, NS = 'http://www.w3.org/2000/svg';
  const ready = () => { window.SCENES_READY = true; };
  const hosts = [...document.querySelectorAll('[data-scene]')];
  if (!D || !T || !hosts.length) return ready();
  const tag = document.createElement('script');
  tag.src = `assets/tex/${D.LANG}.js`;
  tag.onload = () => init().catch(err => { console.error(err); ready(); });
  tag.onerror = ready;
  document.head.append(tag);

  const L = D.L, TAU = Math.PI * 2, ZH = D.LANG === 'zh';
  const V2 = (x, y) => new T.Vector2(x, y), V3 = (x, y, z) => new T.Vector3(x, y, z);
  const clamp = x => Math.max(0, Math.min(1, x));
  const ease = x => 1 - Math.pow(1 - clamp(x), 3);
  const easeIO = x => { x = clamp(x); return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; };
  const live = D.STATIC ? 0 : 1;
  let renderer, ENV, GLOW, AO, MAT, maps = {}, images = {};

  /* ---------- geometry helpers ---------- */
  const cut = (p, q, r) => { const dx = q.x - p.x, dy = q.y - p.y, l = Math.hypot(dx, dy), k = Math.min(r, l / 2.2) / l; return V2(p.x + dx * k, p.y + dy * k); };
  function roundPoly(path, pts, r) {
    pts.forEach((p, i) => {
      const a = cut(p, pts[(i + pts.length - 1) % pts.length], r), b = cut(p, pts[(i + 1) % pts.length], r);
      i ? path.lineTo(a.x, a.y) : path.moveTo(a.x, a.y);
      path.quadraticCurveTo(p.x, p.y, b.x, b.y);
    });
    path.closePath();
    return path;
  }
  // move every edge of a counter-clockwise polygon inwards by t
  function inset(pts, t) {
    const lines = pts.map((p, i) => { const q = pts[(i + 1) % pts.length], dx = q.x - p.x, dy = q.y - p.y, l = Math.hypot(dx, dy); return [p.x - dy / l * t, p.y + dx / l * t, dx, dy]; });
    return lines.map((b, i) => {
      const a = lines[(i + lines.length - 1) % lines.length], den = a[2] * b[3] - a[3] * b[2], s = ((b[0] - a[0]) * b[3] - (b[1] - a[1]) * b[2]) / den;
      return V2(a[0] + a[2] * s, a[1] + a[3] * s);
    });
  }
  const rrect = (w, h, r) => roundPoly(new T.Shape(), [V2(-w / 2, -h / 2), V2(w / 2, -h / 2), V2(w / 2, h / 2), V2(-w / 2, h / 2)], r);
  // flat rounded face with 0..1 UVs, for printed artwork
  function faceGeo(w, h, r) {
    const g = new T.ShapeGeometry(rrect(w, h, r), 12), p = g.attributes.position, uv = g.attributes.uv;
    for (let i = 0; i < p.count; i++) uv.setXY(i, p.getX(i) / w + .5, p.getY(i) / h + .5);
    return g;
  }
  const once = fn => { let v; return () => v ??= fn(); };

  /* ---------- textures ---------- */
  const loadImg = src => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
  const svgURL = m => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(m);
  function texOf(src) {
    const t = src instanceof HTMLCanvasElement ? new T.CanvasTexture(src) : new T.Texture(src);
    t.encoding = T.sRGBEncoding; t.anisotropy = renderer.capabilities.getMaxAnisotropy(); t.needsUpdate = true;
    return t;
  }
  const canvas = (w, h, draw) => { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); return c; };
  const aoTex = () => texOf(canvas(256, 128, (x, w, h) => {
    x.translate(w / 2, h / 2); x.scale(1, h / w);
    const g = x.createRadialGradient(0, 0, 0, 0, 0, w / 2);
    g.addColorStop(0, 'rgba(0,0,0,.85)'); g.addColorStop(.5, 'rgba(0,0,0,.35)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = g; x.fillRect(-w / 2, -w / 2, w, w);
  }));
  const glowTex = () => texOf(canvas(256, 256, (x, w) => {
    const g = x.createRadialGradient(w / 2, w / 2, 0, w / 2, w / 2, w / 2);
    g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(.25, 'rgba(255,255,255,.45)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = g; x.fillRect(0, 0, w, w);
  }));
  // the NFC tag face: blue disc with the contactless mark
  const nfcTex = () => texOf(canvas(512, 512, (x, w) => {
    const g = x.createRadialGradient(w * .42, w * .38, 10, w / 2, w / 2, w / 2);
    g.addColorStop(0, '#5656ff'); g.addColorStop(1, '#2525cf'); x.fillStyle = g; x.fillRect(0, 0, w, w);
    x.strokeStyle = 'rgba(255,255,255,.28)'; x.lineWidth = 6; x.beginPath(); x.arc(w / 2, w / 2, w * .43, 0, TAU); x.stroke();
    x.strokeStyle = '#fff'; x.lineCap = 'round'; x.lineWidth = 24;
    [62, 112, 162].forEach(r => { x.beginPath(); x.arc(w * .36, w / 2, r, -.9, .9); x.stroke(); });
    x.fillStyle = '#fff'; x.beginPath(); x.arc(w * .36, w / 2, 20, 0, TAU); x.fill();
  }));
  // a radial alpha mask (white centre → black edge) so floors fade out
  const fadeTex = () => { const t = new T.CanvasTexture(canvas(512, 512, (x, w) => {
    const g = x.createRadialGradient(w / 2, w / 2, 0, w / 2, w / 2, w / 2);
    g.addColorStop(0, '#fff'); g.addColorStop(.32, '#999'); g.addColorStop(.78, '#000'); x.fillStyle = g; x.fillRect(0, 0, w, w);
  })); return t; };

  /* ---------- studio environment (reflections for clearcoat, metal and glass) ---------- */
  // k scales every light panel; dark rooms keep the strips bright but the walls black, for crisp edge highlights
  function studio(k, dark) {
    const s = new T.Scene(), box = new T.BoxGeometry(1, 1, 1);
    const room = new T.Mesh(box, new T.MeshBasicMaterial({ color: dark ? 0x040405 : 0x141416, side: T.BackSide }));
    room.scale.set(30, 16, 30); s.add(room);
    const panel = (c, i, sx, sy, sz, x, y, z) => { const m = new T.Mesh(box, new T.MeshBasicMaterial({ color: new T.Color(c).multiplyScalar(i * k) })); m.scale.set(sx, sy, sz); m.position.set(x, y, z); s.add(m); };
    panel(0xffffff, 7, 10, .1, 5, 0, 7.8, 2);       // overhead softbox
    panel(0xfff0dc, 3.2, .1, 7, 9, -14.8, 2, 0);   // warm strip, left
    panel(0x7f7fff, 3.6, .1, 7, 9, 14.8, 2, 0);    // blue strip, right
    panel(0xffffff, .8, 14, 4, .1, 0, 2, 14.8);    // front fill
    panel(0xffffff, 2.2, 14, 1, .1, 0, 1.5, -14.8); // back rim
    const pm = new T.PMREMGenerator(renderer), env = pm.fromScene(s, .04).texture;
    pm.dispose();
    return env;
  }

  function materials() {
    const phys = o => new T.MeshPhysicalMaterial(o), faces = {};
    const nfc = nfcTex();
    MAT = {
      body: phys({ color: 0xd6c9ab, roughness: .6, clearcoat: .2, clearcoatRoughness: .5, envMapIntensity: .85 }),
      edge: new T.MeshStandardMaterial({ color: 0xf6f5f1, roughness: .5 }),
      disc: phys({ color: 0x3434e8, roughness: .26, clearcoat: 1, clearcoatRoughness: .08, emissive: 0x2020d0, emissiveIntensity: .45 }),
      discTop: phys({ map: nfc, emissiveMap: nfc, emissive: 0xffffff, emissiveIntensity: .32, roughness: .26, clearcoat: 1, clearcoatRoughness: .06 }),
      titanium: phys({ color: 0x4a4b51, metalness: 1, roughness: .28, clearcoat: .6, clearcoatRoughness: .2 }),
      black: phys({ color: 0x050506, roughness: .1, clearcoat: 1, clearcoatRoughness: .03 }),
      glass: phys({ color: 0xffffff, roughness: .03, transparent: true, opacity: .07, clearcoat: 1, depthWrite: false }),
      face: k => faces[k] ??= phys({ map: maps[k], roughness: .6, specularIntensity: .35, clearcoat: .12, clearcoatRoughness: .3, envMapIntensity: .25 }),
    };
  }

  /* ---------- models ---------- */
  // Stand cross-section (u = depth, front +, v = height): front foot F, apex A, back foot K.
  const ST = { L: 232, F: V2(34, 0), A: V2(-6, 60), K: V2(-30, 0) };
  const SD = V2(-40, 60).normalize(), SN = V2(SD.y, -SD.x);        // up-slope direction and outward normal
  const onSlope = (s, o) => V2(ST.F.x + SD.x * s + SN.x * o, ST.F.y + SD.y * s + SN.y * o);
  const TILT = Math.atan2(SD.x, SD.y);                               // rotation about X that leans a card onto the slope
  const NW = V3(0, SN.y, SN.x), DW = V3(0, SD.y, SD.x);              // the same two directions in world space
  const SLOTS = [-80, -22, 36], CARDS = ['card07', 'card25', 'card36'];

  const cardGeo = once(() => { const g = new T.ExtrudeGeometry(rrect(49, 85, 2.6), { depth: .9, bevelEnabled: false, curveSegments: 6 }); g.translate(0, 0, -.45); return g; });
  const cardFaceGeo = once(() => faceGeo(49, 85, 2.6));
  function card(key) {
    const g = new T.Group(), face = new T.Mesh(cardFaceGeo(), MAT.face(key));
    face.position.z = .46;
    g.add(new T.Mesh(cardGeo(), MAT.edge), face);
    return g;
  }
  const standGeo = once(() => {
    const ext = { depth: ST.L, bevelEnabled: true, bevelThickness: 1.2, bevelSize: 1.2, bevelSegments: 3, curveSegments: 10 };
    const outer = [ST.F, ST.A, ST.K], shell = roundPoly(new T.Shape(), outer, 5);
    shell.holes.push(roundPoly(new T.Path(), inset(outer, 4.6), 2.2));
    const lip = roundPoly(new T.Shape(), [V2(30, 0), V2(52, 0), V2(52, 13), V2(47.5, 13), V2(47.5, 4.5), V2(30, 4.5)], 1.4);
    return { shell: new T.ExtrudeGeometry(shell, ext), lip: new T.ExtrudeGeometry(lip, ext), fin: new T.BoxGeometry(2, 8, 15.5),
      disc: new T.CylinderGeometry(16.5, 16.5, 2.6, 72) };
  });
  function buildStand() {
    const G = standGeo(), g = new T.Group(), prism = new T.Group();
    prism.add(new T.Mesh(G.shell, MAT.body), new T.Mesh(G.lip, MAT.body));
    prism.rotation.y = -Math.PI / 2; prism.position.x = ST.L / 2;       // extrusion runs along world X, front faces +Z
    g.add(prism);
    [-51, 7, 65].forEach(x => { const f = new T.Mesh(G.fin, MAT.body); f.position.set(x, 8.5, 39.5); g.add(f); });
    const p = onSlope(5.4 + 42.5, 2.6);
    const cards = CARDS.map((k, i) => { const c = card(k); c.position.set(SLOTS[i], p.y, p.x); c.rotation.x = TILT; g.add(c); return c; });
    const disc = new T.Group(), dp = onSlope(30, 3.9);
    disc.position.set(92, dp.y, dp.x); disc.rotation.x = Math.PI / 2 + TILT;
    disc.add(new T.Mesh(G.disc, [MAT.disc, MAT.discTop, MAT.disc]));
    g.add(disc);
    g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    const ao = new T.Mesh(new T.PlaneGeometry(330, 150), new T.MeshBasicMaterial({ map: AO, transparent: true, depthWrite: false, opacity: .55 }));
    ao.rotation.x = -Math.PI / 2; ao.position.set(0, .15, 12); ao.renderOrder = -2; g.add(ao);
    g.userData = { cards, disc, ao };
    return g;
  }
  // light rings, glow and a point light on the NFC tag; returns update(t, strength, glow)
  // mode: 'dark' (additive light) · 'paper' (blue ink) · 'blue' (white on the blue slide)
  function nfcFX(disc, mode = 'dark') {
    const blending = mode === 'dark' ? T.AdditiveBlending : T.NormalBlending;
    const tint = { dark: [0x5c5cff, 0x9a9aff], paper: [0x4646ff, 0x3a3af0], blue: [0xffffff, 0xffffff] }[mode];
    const glow = new T.Sprite(new T.SpriteMaterial({ map: GLOW, color: tint[0], blending, depthWrite: false, transparent: true }));
    glow.scale.set(96, 96, 1); glow.position.y = 5; disc.add(glow);
    const ringGeo = new T.RingGeometry(16.6, 17.8, 72);
    const rings = [0, 1, 2].map(() => {
      const m = new T.Mesh(ringGeo, new T.MeshBasicMaterial({ color: tint[1], blending, transparent: true, depthWrite: false, side: T.DoubleSide }));
      m.rotation.x = -Math.PI / 2; m.position.y = 1.6; disc.add(m); return m;
    });
    const light = new T.PointLight(0x6262ff, 0, 220, 1.6); light.position.y = 16; disc.add(light);
    return (t, k = 1, g = k) => {
      rings.forEach((m, i) => { const p = (t * .5 + i / 3) % 1; m.scale.setScalar(1 + p * 2.1); m.material.opacity = Math.pow(1 - p, 1.4) * .95 * k; });
      glow.material.opacity = (.5 + .22 * Math.sin(t * 3.1)) * g;
      light.intensity = 2.2 * k;
    };
  }
  const phoneGeo = once(() => {
    const W = 71.5, H = 149, R = 11.5;
    const body = new T.ExtrudeGeometry(rrect(W - 2.4, H - 2.4, R - 1.2), { depth: 5.4, bevelEnabled: true, bevelThickness: 1.1, bevelSize: 1.2, bevelSegments: 5, curveSegments: 16 });
    body.translate(0, 0, -2.7);
    return { body, screen: faceGeo(W - 4.6, H - 4.6, R - 2.4), glass: faceGeo(W - 1, H - 1, R - .6) };
  });
  function buildPhone(key) {
    const G = phoneGeo(), g = new T.Group();
    const screen = new T.Mesh(G.screen, new T.MeshBasicMaterial({ map: maps[key], toneMapped: false }));
    const glass = new T.Mesh(G.glass, MAT.glass);
    screen.position.z = 3.83; glass.position.z = 3.9;
    g.add(new T.Mesh(G.body, [MAT.black, MAT.titanium]), screen, glass);
    g.traverse(o => { if (o.isMesh) o.castShadow = true; });
    return g;
  }

  /* ---------- lights, camera, floors ---------- */
  function rig(scene, { dark = false, shadow = .22, box = 240 } = {}) {
    scene.environment = dark ? ENV.dark : ENV.light;
    const key = new T.DirectionalLight(0xfff3e4, dark ? 1.1 : 1.7);
    key.position.set(-180, 320, 240); key.castShadow = true;
    Object.assign(key.shadow.camera, { left: -box, right: box, top: box, bottom: -box, near: 50, far: 1000 });
    key.shadow.mapSize.setScalar(D.STATIC ? 2048 : 1024); key.shadow.bias = -.0004; key.shadow.normalBias = .5; key.shadow.radius = 5;
    const rim = new T.DirectionalLight(0x6f6fff, dark ? 3.4 : 1); rim.position.set(280, 170, -240);
    const back = new T.DirectionalLight(0xffffff, dark ? 1.7 : .55); back.position.set(-280, 140, -200);
    scene.add(key, rim, back, new T.HemisphereLight(0xffffff, 0x1b1b26, dark ? .16 : .3));
    scene.userData.exposure = dark ? .82 : .6;           // r149's ACES already lifts by 1 / 0.6
    scene.userData.light = !dark;
    const ground = new T.Mesh(new T.PlaneGeometry(2400, 2400), new T.ShadowMaterial({ opacity: shadow }));
    ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
    return { key, rim };
  }
  function setCam(cam, target, dist, az, el) {
    const a = az * Math.PI / 180, e = el * Math.PI / 180;
    cam.position.set(target.x + dist * Math.sin(a) * Math.cos(e), target.y + dist * Math.sin(e), target.z + dist * Math.cos(a) * Math.cos(e));
    cam.lookAt(target);
  }
  // dark glossy floor with a fading mirror image of `world` underneath (for the black slides)
  function mirrorFloor(scene, world, radius = 520) {
    const mirror = world.clone();
    mirror.scale.y = -1;
    mirror.traverse(o => { o.castShadow = false; if (o.isLight) o.visible = false; });
    const floor = new T.Mesh(new T.CircleGeometry(radius, 96), new T.MeshStandardMaterial({ color: 0x060607, roughness: .4, metalness: .1, transparent: true, opacity: .965, alphaMap: fadeTex(), envMapIntensity: .1 }));
    floor.rotation.x = -Math.PI / 2; floor.position.y = -.05; floor.renderOrder = -1;
    scene.add(mirror, floor);
    const a = [], b = [];
    world.traverse(o => a.push(o)); mirror.traverse(o => b.push(o));
    a.forEach((o, i) => { if (o.userData.noMirror) b[i].visible = false; });   // same traversal order in both trees
    return () => { a.forEach((o, i) => { if (!i) { b[0].rotation.y = o.rotation.y; return; } b[i].position.copy(o.position); b[i].quaternion.copy(o.quaternion); b[i].scale.copy(o.scale); }); };
  }

  /* ---------- views: render the scene, copy into the host's own canvas ---------- */
  // Soft edges are baked into the canvas (CSS masks are dropped when Chromium prints to PDF).
  function bakeFade(ctx, W, H, f) {
    const ramp = (g, a, b) => {
      g.addColorStop(0, a ? 'rgba(0,0,0,0)' : '#000'); g.addColorStop(Math.max(a, .0001), '#000');
      g.addColorStop(Math.min(1 - b, .9999), '#000'); g.addColorStop(1, b ? 'rgba(0,0,0,0)' : '#000');
      return g;
    };
    ctx.save(); ctx.globalCompositeOperation = 'destination-in';
    ctx.fillStyle = ramp(ctx.createLinearGradient(0, 0, W, 0), f.l || 0, f.r || 0); ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = ramp(ctx.createLinearGradient(0, 0, 0, H), f.t || 0, f.b || 0); ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }
  function view(host, scene, camera, update, fade) {
    const w = host.clientWidth, h = host.clientHeight, pr = D.STATIC ? 2 : Math.min(1.5, devicePixelRatio || 1);
    const cv = document.createElement('canvas');
    cv.className = 'gl'; cv.width = Math.round(w * pr); cv.height = Math.round(h * pr);
    host.prepend(cv);
    const ctx = cv.getContext('2d');
    camera.aspect = w / h; camera.updateProjectionMatrix();
    renderer.compile(scene, camera);                       // compile shaders now, not on the first frame of the slide
    const v = { host, w, h, scene, camera, cv };
    let last = 0;
    const frame = (t, age) => {
      const dt = Math.min(.1, Math.max(0, t - last)); last = t;
      update(t, age, v, D.STATIC ? 99 : dt);
      scene.updateMatrixWorld();
      v.after?.(v);
      if (renderer.domElement.width !== cv.width || renderer.domElement.height !== cv.height) renderer.setSize(cv.width, cv.height, false);
      renderer.toneMappingExposure = scene.userData.exposure ?? 1;
      renderer.render(scene, camera);
      ctx.clearRect(0, 0, cv.width, cv.height);
      ctx.drawImage(renderer.domElement, 0, 0);
      if (fade) bakeFade(ctx, cv.width, cv.height, fade);
    };
    if (D.STATIC) frame(0, 99); else D.loop(host.closest('.slide'), frame);
    return v;
  }
  const toScreen = (v, obj, p) => { const q = p.clone(); obj.localToWorld(q); q.project(v.camera); return [(q.x + 1) / 2 * v.w, (1 - q.y) / 2 * v.h]; };
  // leader lines from projected 3D anchors to HTML labels inside the host; returns update(v)
  function leaders(host, items) {
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('class', 'leads'); svg.setAttribute('width', host.clientWidth); svg.setAttribute('height', host.clientHeight);
    host.prepend(svg);                                   // view() later puts its canvas underneath
    const rows = items.filter(it => it.el).map(it => {
      const p = document.createElementNS(NS, 'path'), c = document.createElementNS(NS, 'circle'), c2 = document.createElementNS(NS, 'circle');
      c.setAttribute('r', 4.5); c2.setAttribute('r', 11); c2.setAttribute('class', 'halo');
      if (it.el.dataset.step) [p, c, c2].forEach(n => n.setAttribute('data-lstep', it.el.dataset.step));
      svg.append(p, c2, c); return { p, c, c2, it };
    });
    return v => rows.forEach(({ p, c, c2, it }) => {
      const [ax, ay] = it.get(v), e = it.el, left = ax < e.offsetLeft + e.offsetWidth / 2;
      const lx = left ? e.offsetLeft - 14 : e.offsetLeft + e.offsetWidth + 14, ly = e.offsetTop + (it.dy ?? 12), ex = lx + (left ? -36 : 36);
      p.setAttribute('d', `M${ax.toFixed(1)} ${ay.toFixed(1)}L${ex.toFixed(1)} ${ly}L${lx} ${ly}`);
      [c, c2].forEach(n => { n.setAttribute('cx', ax.toFixed(1)); n.setAttribute('cy', ay.toFixed(1)); });
    });
  }
  const discWorld = stand => stand.userData.disc.localToWorld(V3(0, 0, 0));

  /* ---------- slide scenes ---------- */
  const SCENE = {};

  // 16 · the crit stand as a studio product shot, slowly turning; labels follow the parts.
  SCENE.stand = host => {
    const scene = new T.Scene(), cam = new T.PerspectiveCamera(22, 1, 10, 5000);
    rig(scene, { shadow: .3 });
    const stand = buildStand(), fx = nfcFX(stand.userData.disc, 'paper');
    scene.add(stand);
    setCam(cam, V3(6, 30, 6), 600, -26, 15);
    const { cards, disc } = stand.userData, q = s => host.querySelector(`[data-at="${s}"]`);
    const lead = leaders(host, [
      { el: q('card'), get: v => toScreen(v, cards[1], V3(0, 41, 1)) },
      { el: q('disc'), get: v => toScreen(v, disc, V3(0, 1.4, 0)) },
      { el: q('ledge'), get: v => toScreen(v, stand, V3(-40, 13, 51)) },
      { el: q('frame'), get: v => toScreen(v, stand, V3(-117, 50, -5)) },
    ]);
    const v = view(host, scene, cam, (t, age) => {
      const e = ease((age - .2) / 1.5);
      stand.rotation.y = -.1 + live * .2 * Math.sin(t * .3);
      stand.position.y = -30 * (1 - e);
      fx(t, .8, .5);
    }, { l: .07, b: .1 });
    v.after = lead; v.after(v);
  };

  // 14 · the stand as one of three touchpoints, floating on the blue plane.
  SCENE.sys = host => {
    const scene = new T.Scene(), cam = new T.PerspectiveCamera(24, 1, 10, 5000);
    rig(scene, { shadow: .32 });
    const stand = buildStand(), fx = nfcFX(stand.userData.disc, 'blue');
    scene.add(stand);
    setCam(cam, V3(4, 34, 6), 450, 24, 19);
    view(host, scene, cam, (t, age) => {
      const e = ease((age - .6) / 1.4);
      stand.rotation.y = .1 + live * .3 * Math.sin(t * .26);
      stand.position.y = -36 * (1 - e) + live * 2.5 * Math.sin(t * 1.1);
      fx(t, .9, .4);
    });
  };

  // 17 · storyboard frame: the tutor's phone taps the stand at the crit table.
  SCENE.tap = host => {
    const scene = new T.Scene(), cam = new T.PerspectiveCamera(30, 1, 10, 5000);
    rig(scene, { dark: true, shadow: .55 });
    const stand = buildStand(), fx = nfcFX(stand.userData.disc), phone = buildPhone('tview');
    scene.add(stand, phone);
    scene.updateMatrixWorld();
    const d0 = discWorld(stand);
    setCam(cam, V3(d0.x - 40, d0.y + 30, d0.z), 760, 36, 20);
    phone.rotation.set(TILT, -.16, -.12);
    view(host, scene, cam, (t, age) => {
      const tap = live ? .5 + .5 * Math.sin(t * 2) : .2, hover = 18 + 26 * tap;
      phone.position.copy(d0).addScaledVector(NW, hover).addScaledVector(DW, 34).add(V3(-8, 0, 0));
      fx(t, 1.25 - tap * .6);
    });
  };

  // 20 · launch hero: stand, cards and the tutor's phone over a dark mirror floor.
  SCENE.hero = host => {
    const scene = new T.Scene(), cam = new T.PerspectiveCamera(24, 1, 10, 6000);
    rig(scene, { dark: true, shadow: .6, box: 300 });
    const world = new T.Group(), stand = buildStand(), phone = buildPhone('tview'), fx = nfcFX(stand.userData.disc);
    phone.traverse(o => { o.castShadow = false; });
    phone.userData.noMirror = true;
    // a stream of light from the tag to the phone: the tap, made visible
    const N = 46, beamGeo = new T.BufferGeometry(), beamPos = new Float32Array(N * 3);
    beamGeo.setAttribute('position', new T.BufferAttribute(beamPos, 3));
    const beam = new T.Points(beamGeo, new T.PointsMaterial({ map: GLOW, color: 0x9a9aff, size: 7, transparent: true, depthWrite: false, blending: T.AdditiveBlending }));
    beam.userData.noMirror = true; beam.frustumCulled = false;
    world.add(stand, phone, beam); scene.add(world);
    scene.updateMatrixWorld();
    const d0 = discWorld(stand), sync = mirrorFloor(scene, world, 400);
    const target = V3(34, 60, 12);
    view(host, scene, cam, (t, age) => {
      const e = easeIO((age - .1) / 2.6);
      setCam(cam, target, 1000 - 250 * e, -36 + 14 * e + live * 5 * Math.sin(t * .18), 9 + 5 * e);
      world.rotation.y = live * .05 * Math.sin(t * .23);
      const bob = live * 3 * Math.sin(t * 1.3);
      phone.position.set(d0.x + 70, 80 + bob, d0.z + 40);
      phone.rotation.set(-.42, -.62, -.08);
      // quadratic path disc → back of the phone; particles drift along it
      const a = d0.clone().addScaledVector(NW, 4), c = phone.position.clone().add(V3(-12, -8, -6)), m = a.clone().lerp(c, .5).add(V3(0, 26, 6));
      for (let i = 0; i < N; i++) {
        const u = ((i / N) + (live ? t * .35 : .3)) % 1, w = 1 - u;
        beamPos.set([w * w * a.x + 2 * w * u * m.x + u * u * c.x, w * w * a.y + 2 * w * u * m.y + u * u * c.y, w * w * a.z + 2 * w * u * m.z + u * u * c.z], i * 3);
      }
      beamGeo.attributes.position.needsUpdate = true;
      fx(t, 1);
      sync();
    }, { l: .24, b: .2, r: .05 });
  };

  // 15 · one decision card as six glass layers; → explodes them. Each layer carries its own content.
  const FONT = {
    disp: '"Unbounded", "Noto Sans SC Variable", sans-serif',
    mono: '"JB Mono", "Noto Sans SC Variable", monospace',
    sans: ZH ? '"Noto Sans SC Variable", sans-serif' : '"Trace Sans", sans-serif',
  };
  function wrap(x, text, max) {
    const out = []; let line = '';
    for (const tok of ZH ? [...text] : text.split(/(?<=\s)/)) {
      if (line && x.measureText(line + tok).width > max) { out.push(line.trim()); line = ''; }
      line += tok;
    }
    return out.concat(line.trim());
  }
  const cover = (x, img, X, Y, w, h, r, bg) => {
    x.save(); x.beginPath(); x.roundRect(X, Y, w, h, r); x.clip(); x.fillStyle = bg; x.fillRect(X, Y, w, h);
    const s = Math.max(w / img.width, h / img.height); x.drawImage(img, X + (w - img.width * s) / 2, Y + (h - img.height * s) / 2, img.width * s, img.height * s);
    x.restore();
  };
  const head = (x, n, txt) => {
    x.font = `500 19px ${FONT.mono}`; x.letterSpacing = '3px'; x.fillStyle = 'rgba(255,255,255,.62)';
    x.fillText(`${n}  ${txt}`.toUpperCase(), 34, 60); x.letterSpacing = '0px';
    x.fillStyle = 'rgba(255,255,255,.25)'; x.fillRect(34, 78, 422, 1.5);
  };
  const ORANGE = '#e0632d';
  const LAYERS = [
    x => { head(x, '01', L('AI output · Vizcom', 'AI 输出 · Vizcom')); cover(x, images.render25, 34, 104, 422, 560, 24, '#e9e8e3'); },
    x => {
      head(x, '02', L('Rule in force', '当时的规范'));
      x.fillStyle = '#fff'; x.font = `300 150px ${FONT.disp}`; x.letterSpacing = '-8px'; x.fillText('v1', 26, 280); x.letterSpacing = '0px';
      x.font = `500 21px ${FONT.mono}`; x.fillStyle = '#a6a6ff'; x.fillText(L('SKETCHING', '草图阶段'), 36, 330);
      x.font = `400 ${ZH ? 31 : 30}px ${FONT.sans}`; x.fillStyle = 'rgba(255,255,255,.9)';
      wrap(x, L('Start with your own hand sketch. You may refine it with AI. If you use an AI-assisted version, keep the original and explain what changed.',
        '先画手绘草图。可用 AI 细化自己画的草图。采用 AI 辅助版本时，保留原稿并写明改动。'), 410).forEach((ln, i) => x.fillText(ln, 36, 400 + i * 44));
    },
    x => {
      head(x, '03', L('Decision', '决定'));
      x.fillStyle = ORANGE; x.beginPath(); x.roundRect(34, 300, 422, 170, 28); x.fill();
      x.fillStyle = 'rgba(255,255,255,.22)'; x.beginPath(); x.arc(104, 385, 40, 0, TAU); x.fill();
      x.strokeStyle = '#fff'; x.lineWidth = 7; x.lineCap = 'round'; x.lineJoin = 'round';
      x.beginPath(); x.moveTo(88, 402); x.lineTo(92, 384); x.lineTo(112, 364); x.lineTo(124, 376); x.lineTo(104, 396); x.closePath(); x.stroke();
      x.fillStyle = '#fff'; x.font = `600 ${ZH ? 60 : 54}px ${FONT.disp}`; x.letterSpacing = '-2px'; x.fillText(L('Changed', '修改'), 166, 406); x.letterSpacing = '0px';
      x.font = `500 18px ${FONT.mono}`; x.fillStyle = 'rgba(255,255,255,.75)'; x.fillText(L('FINAL VERSION', '最终版本'), 36, 520);
      ['kept', 'rejected'].forEach((k, i) => { x.strokeStyle = 'rgba(255,255,255,.3)'; x.lineWidth = 2; x.beginPath(); x.roundRect(34 + i * 216, 560, 206, 74, 18); x.stroke();
        x.fillStyle = 'rgba(255,255,255,.45)'; x.font = `500 24px ${FONT.sans}`; x.fillText(i ? L('Rejected', '放弃') : L('Kept', '保留'), 60 + i * 216, 606); });
    },
    x => {
      head(x, '04', L('Why · in my words', '理由 · 自己的话'));
      x.fillStyle = ORANGE; x.fillRect(34, 180, 7, 330);
      x.fillStyle = '#fff'; x.font = `400 ${ZH ? 44 : 41}px ${FONT.sans}`;
      wrap(x, L('Kept the silhouette; moved the controls to the top so it works one-handed.', '保留了轮廓，把控制键移到顶部，方便单手操作。'), 380)
        .forEach((ln, i) => x.fillText(ln, 66, 222 + i * 60));
      x.font = `500 18px ${FONT.mono}`; x.fillStyle = 'rgba(255,255,255,.55)'; x.fillText(L('#ERGONOMICS  ·  67 / 100', '#人机工程  ·  23 / 100'), 36, 600);
    },
    x => { head(x, '05', L('My revision', '我的修改稿')); cover(x, images.sketch25, 34, 104, 422, 560, 24, '#fbfaf6'); },
    x => {
      head(x, '06', L('Visibility', '可见范围'));
      const sw = (y, on, txt) => {
        x.fillStyle = on ? '#fff' : 'rgba(255,255,255,.14)'; x.beginPath(); x.roundRect(34, y, 128, 72, 36); x.fill();
        x.fillStyle = on ? '#3a3af0' : 'rgba(255,255,255,.5)'; x.beginPath(); x.arc(on ? 126 : 70, y + 36, 26, 0, TAU); x.fill();
        x.fillStyle = on ? '#fff' : 'rgba(255,255,255,.45)'; x.font = `${on ? 600 : 400} ${on ? 40 : 32}px ${FONT.sans}`; x.fillText(txt, 188, y + 50);
      };
      sw(300, true, L('Only me', '仅自己可见')); sw(420, false, L('Tutor can see', '老师可见'));
      x.font = `500 18px ${FONT.mono}`; x.fillStyle = 'rgba(255,255,255,.6)'; x.fillText(L('PRIVATE UNTIL SHARED', '分享之前仅自己可见'), 36, 600);
    },
  ];
  SCENE.explode = host => {
    const scene = new T.Scene(), cam = new T.PerspectiveCamera(26, 1, 10, 6000);
    rig(scene, { dark: true, shadow: .38, box: 260 });
    const W = 49, H = 85, stack = new T.Group();
    scene.add(stack);
    const slab = new T.ExtrudeGeometry(rrect(W, H, 4.2), { depth: 1.2, bevelEnabled: true, bevelThickness: .45, bevelSize: .45, bevelSegments: 3, curveSegments: 12 });
    slab.translate(0, 0, -.6);
    const edges = new T.EdgesGeometry(slab, 25), face = faceGeo(W - 1.6, H - 1.6, 3.6);
    const edgeMat = new T.LineBasicMaterial({ color: 0xb4b4ff, transparent: true, opacity: .55, blending: T.AdditiveBlending, depthWrite: false });
    const layers = LAYERS.map((draw, k) => {
      const g = new T.Group();
      const glass = new T.MeshPhysicalMaterial({ color: k === 5 ? 0x7070ff : 0xe6e8ff, transparent: true, opacity: k === 5 ? .3 : .14, roughness: .05,
        clearcoat: 1, clearcoatRoughness: .03, envMapIntensity: 2.4, side: T.DoubleSide, depthWrite: false });
      const art = new T.Mesh(face, new T.MeshBasicMaterial({ map: texOf(canvas(980, 1700, x => { x.scale(2, 2); draw(x); })), transparent: true, depthWrite: false, toneMapped: false }));
      art.position.z = 1.08;
      g.add(new T.Mesh(slab, glass), new T.LineSegments(edges, edgeMat), art);
      g.rotation.x = -Math.PI / 2;
      stack.add(g);
      return g;
    });
    // the printed card face sits on top while the stack is closed
    const top = new T.Mesh(face, new T.MeshBasicMaterial({ map: maps.card25, transparent: true, depthWrite: false, toneMapped: false }));
    top.position.z = 1.2; layers[0].add(top);
    // a pool of blue light on the floor under the stack
    const pool = new T.Mesh(new T.PlaneGeometry(380, 260), new T.MeshBasicMaterial({ map: GLOW, color: 0x3a3aff, blending: T.AdditiveBlending, transparent: true, depthWrite: false, opacity: .75 }));
    pool.rotation.x = -Math.PI / 2; pool.position.y = .6; scene.add(pool);
    const dust = new T.BufferGeometry(), N = 340, pos = new Float32Array(N * 3), r = (a, b) => a + Math.random() * (b - a);
    for (let i = 0; i < N; i++) pos.set([r(-200, 200), r(-10, 250), r(-160, 160)], i * 3);
    dust.setAttribute('position', new T.BufferAttribute(pos, 3));
    const motes = new T.Points(dust, new T.PointsMaterial({ map: GLOW, color: 0x9a9aff, size: 2.6, transparent: true, depthWrite: false, blending: T.AdditiveBlending, opacity: .7 }));
    scene.add(motes);
    stack.rotation.set(0, .72, 0);
    setCam(cam, V3(78, 104, 0), 480, 0, 34);
    const sl = host.closest('.slide');
    let p = D.STATIC ? +(sl.dataset.cur || 0) : 0;
    const corner = g => { const c = [[1, 1], [1, -1], [-1, 1], [-1, -1]].map(([sx, sy]) => V3(sx * W / 2, sy * H / 2, 1)); return v => c.map(q => toScreen(v, g, q)).sort((a, b) => b[0] - a[0])[0]; };
    const lead = leaders(host, layers.map((g, k) => ({ el: host.querySelector(`.lab[data-k="${k}"]`), get: corner(g) })));
    const v = view(host, scene, cam, (t, age, v, dt) => {
      const goal = +(sl.dataset.cur || 0) >= 1 ? 1 : 0;
      p += (goal - p) * (1 - Math.exp(-dt * 2.6));
      const base = 14 + 74 * (1 - easeIO(p));                  // the closed card floats mid-frame, the open stack stands on the floor
      layers.forEach((g, k) => { const e = easeIO(p * 1.35 - (goal ? k * .07 : (5 - k) * .05)); g.position.y = base + (5 - k) * (2.1 + 34 * e); });
      top.material.opacity = 1 - ease(p * 2.4);
      stack.rotation.y = .72 + live * .07 * Math.sin(t * .35);
      stack.position.y = live * 2.4 * Math.sin(t * .8) + (1 - ease(age / 1.4)) * -40;
      motes.rotation.y = t * .03;
      host.style.setProperty('--open', p.toFixed(3));
    }, { l: .08, b: .14 });
    v.after = lead; v.after(v);
  };

  async function init() {
    renderer = new T.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(1);
    renderer.outputEncoding = T.sRGBEncoding;
    renderer.toneMapping = T.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = T.PCFSoftShadowMap;
    renderer.setClearColor(0x000000, 0);
    const TEX = window.TEX || {};
    const [card07, card25, card36, tview, render25, sketch25] = await Promise.all([TEX.card07, TEX.card25, TEX.card36, TEX.tview,
      TEX.render25, TEX.sketch25].map(loadImg));
    Object.assign(images, { render25, sketch25 });
    maps = { card07: texOf(card07), card25: texOf(card25), card36: texOf(card36), tview: texOf(tview) };
    await document.fonts.ready;
    await Promise.all(['300 40px Unbounded', '600 40px Unbounded', '500 20px "JB Mono"', ZH ? '400 30px "Noto Sans SC Variable"' : '400 30px "Trace Sans"']
      .map(f => document.fonts.load(f, ZH ? '修改规范' : 'Changed').catch(() => {})));
    ENV = { light: studio(.34), dark: studio(.6, true) }; GLOW = glowTex(); AO = aoTex(); materials();
    hosts.forEach(h => { try { SCENE[h.dataset.scene]?.(h); } catch (e) { console.error('scene', h.dataset.scene, e); } });
    ready();
  }
})();
